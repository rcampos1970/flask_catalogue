from flask import Flask, render_template, request
from openpyxl import load_workbook
app = Flask(__name__)


@app.route("/", methods=["POST", "GET"])
def home():
    print(request.form["nm"])
    print(request.form["ds"])
    print(request.form["pr"])

    name = request.form["nm"]
    description = request.form["ds"]
    price = request.form["pr"]

    wb = load_workbook("Cathalogue.xlsx")
    ws = wb.active

    ws.cell(6, 1, name)
    ws.cell(6, 2, description)
    ws.cell(6, 3, price)
    wb.save("Cathalogue.xlsx")

    return render_template("index.html")


if __name__ == "__main__":
    app.run()
